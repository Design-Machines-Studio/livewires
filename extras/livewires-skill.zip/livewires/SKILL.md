---
name: livewires
description: Live Wires CSS framework for editorial websites. Use when building HTML pages, writing CSS, or advising on layout and styling. Provides layout primitives (stack, grid, cluster, sidebar, center, section, cover), utility classes, and design tokens based on a baseline rhythm system.
---

# Live Wires CSS Framework

## Philosophy

**Good defaults + additive art direction.** Semantic HTML looks good with zero classes. Utility classes provide precise control for art direction.

**Nothing gets thrown away.** The prototype becomes the product. Every step builds on the last.

## The Design Process

Live Wires follows a sculptural approach—start with raw material, shape the form, refine the details, add expression.

### Step 1: Prototype in HTML
Build page templates using semantic HTML and layout primitives in the `public/` folder. Your prototype is instantly viewable in real browsers across devices. Share with clients, test UX flows, use the redact feature to focus on layout without words.

### Step 2: Set Your Tokens
Adjust design tokens (colors, typography, spacing) in `src/css/1_tokens/`. Watch the [Manual](/manual/) transform in real time. Every token you set designs the foundation of your project.

### Step 3: Refine and Express
Expand your CSS. Add utility classes for art direction. Refine components. Each iteration takes you from coarse to detailed—like carving marble.

### Step 4: Apply to Production
Connect your templates to your CMS or framework. Your prototype becomes the product. The same code, evolved—not translated.

**Alternative: CMS-first** — Install Live Wires directly on your CMS and start content modeling immediately with a prototype front-end.

## Documentation

### Framework Docs (`/docs/`)
How to use Live Wires - installation, architecture, reference:

- **[/docs/](http://localhost:3000/docs/)** — Documentation overview
- **[/docs/getting-started.html](http://localhost:3000/docs/getting-started.html)** — Installation and setup
- **[/docs/utility-classes.html](http://localhost:3000/docs/utility-classes.html)** — Spacing, typography, color utilities
- **[/docs/typography.html](http://localhost:3000/docs/typography.html)** — Typography system

### Manual (`/manual/`)
Brand identity and UI components. Edit tokens—this transforms in real time:

- **[/manual/](http://localhost:3000/manual/)** — Manual hub
- **[/manual/brand/](http://localhost:3000/manual/brand/)** — Logos, colors, fonts, voice & tone
- **[/manual/components/](http://localhost:3000/manual/components/)** — Layout primitives, forms, tables, schemes

Key component reference pages:
- **[Layout primitives](/manual/components/layout.html)** — Stack, grid, cluster, sidebar, center, section, cover, box
- **[Typography](/manual/components/typography.html)** — Type scale, weights, alignment, special treatments
- **[Color schemes](/manual/components/schemes.html)** — Background/foreground pairings

## The Sacred Baseline System

All spacing derives from `--line`. Use `--line-*` tokens for spacing:

```
--line-0, --line-025, --line-05, --line-075, --line-1, --line-15, --line-2, --line-3, --line-4, --line-5, --line-6, --line-7, --line-8, --line-1px
```

## CSS Cascade Layers

```css
@layer tokens, reset, base, layouts, components, utilities;
```

Utilities always win over components, components over layouts, etc.

## Layout Primitives

### Stack (Vertical Spacing)
```html
<div class="stack">                  <!-- Default: var(--line) -->
<div class="stack stack-compact">    <!-- var(--line-025) -->
<div class="stack stack-half">       <!-- var(--line-05) -->
<div class="stack stack-comfortable"><!-- var(--line-2) -->
<div class="stack stack-spacious">   <!-- var(--line-4) -->
```

### Grid (Auto-Responsive)
```html
<div class="grid">                   <!-- Auto-fit -->
<div class="grid grid-narrow">       <!-- Narrower min column width -->
<div class="grid grid-columns-2">    <!-- Fixed columns -->
<div class="grid grid-columns-2@md"> <!-- 2 cols at 40rem+ container -->
<div class="grid grid-columns-3@lg"> <!-- 3 cols at 60rem+ container -->
<div class="grid-column-span-2">     <!-- Span columns -->
<div class="grid-column-span-2@md">  <!-- Responsive span -->
```

### Cluster (Horizontal Grouping)
```html
<nav class="cluster">
<div class="cluster cluster-compact">  <!-- var(--line-05) gap -->
<div class="cluster cluster-center">   <!-- justify-content: center -->
<div class="cluster cluster-end">      <!-- justify-content: flex-end -->
<div class="cluster cluster-between">  <!-- justify-content: space-between -->
```

### Sidebar
```html
<div class="sidebar">
<div class="sidebar sidebar-snug">     <!-- var(--line-1) gap -->
<div class="sidebar sidebar-loose">    <!-- var(--line-2) gap -->
<div class="sidebar sidebar-reverse">  <!-- Sidebar on right -->
```

### Center (Max-Width Container)
```html
<div class="center">
<div class="center center-narrow">
<div class="center center-wide">
```

### Section (Vertical Padding)
```html
<section class="section">
<section class="section section-spaced">       <!-- Top + bottom padding -->
<section class="section section-snug">         <!-- Smaller top + bottom -->
<section class="section section-tight">        <!-- No vertical padding -->
<section class="section section-top-tight">    <!-- No top padding -->
<section class="section section-bottom-tight"> <!-- No bottom padding -->
<section class="section section-wide">         <!-- Narrower horizontal padding -->
<section class="section section-full-bleed">   <!-- No padding at all -->
```

### Cover (Full-Height Centering)
```html
<header class="cover">  <!-- min-height: 100vh, flexbox centering -->
```

### Box (Padding Wrapper)
```html
<div class="box">         <!-- var(--line-1) padding -->
<div class="box box-tight"> <!-- var(--line-05) padding -->
<div class="box box-loose"> <!-- var(--line-2) padding -->
```

## Typography Utilities

```html
<!-- Sizes -->
<p class="text-xs">  <p class="text-sm">  <p class="text-base">
<p class="text-lg">  <p class="text-xl">  <p class="text-2xl">
<p class="text-3xl"> <p class="text-4xl"> <p class="text-5xl"> <p class="text-6xl">
<p class="text-7xl"> <p class="text-8xl"> <p class="text-9xl">

<!-- Responsive sizes (container queries) -->
<h1 class="text-4xl text-6xl@md text-8xl@lg">  <!-- Scales up at breakpoints -->

<!-- Weights -->
<p class="font-light">  <p class="font-normal">  <p class="font-medium">
<p class="font-semibold">  <p class="font-bold">  <p class="font-black">

<!-- Alignment -->
<p class="text-left">  <p class="text-center">  <p class="text-right">

<!-- Special -->
<p class="lead">       <!-- Larger intro paragraph -->
<p class="measure">    <!-- Optimal reading width (65ch) -->
<span class="dropcap"> <!-- Large initial letter -->
```

## Spacing Utilities

```html
<!-- Margin: mt, mb, my, ml, mr, mx -->
<div class="mt-2">  <!-- margin-block-start: var(--line-2) -->
<div class="mb-3">  <!-- margin-block-end: var(--line-3) -->
<div class="my-4">  <!-- margin-block: var(--line-4) -->

<!-- Padding: pt, pb, py, pl, pr, px, p -->
<div class="py-3">  <!-- padding-block: var(--line-3) -->
<div class="px-2">  <!-- padding-inline: var(--line-2) -->
<div class="p-4">   <!-- padding: var(--line-4) -->
```

Values: 0, 025, 05, 075, 1, 15, 2, 3, 4, 5, 6

## Color Schemes

```html
<section class="scheme-subtle">    <!-- Light grey -->
<section class="scheme-dark">      <!-- Dark bg, light text -->
<section class="scheme-grey-100">  <!-- Grey 100 -->
<section class="scheme-grey-200">  <!-- Grey 200 -->

<!-- Background/text colors -->
<div class="bg-white">  <div class="bg-black">  <div class="bg-grey-100">
<p class="text-white">  <p class="text-muted">  <p class="text-grey-500">
```

## Container Query Breakpoints

- `@md` = 40rem container width
- `@lg` = 60rem container width

```html
<!-- Grid -->
<div class="grid-columns-2@md">     <!-- 2 cols at 40rem+ -->
<div class="grid-column-span-2@lg"> <!-- Span 2 at 60rem+ -->

<!-- Typography -->
<h1 class="text-4xl text-6xl@md text-8xl@lg"> <!-- Scales up at breakpoints -->

<!-- Order -->
<div class="order-first@md">        <!-- Order first at 40rem+ -->
```

## Common Patterns

### Article Structure
```html
<article class="prose">
  <header class="section scheme-subtle">
    <h1 class="text-6xl">Title</h1>
    <p class="lead">Subtitle.</p>
    <p>By Author &middot; <time datetime="2024-01-15">January 15, 2024</time></p>
  </header>
  <figure class="section section-tight">
    <img src="hero.jpg" alt="" />
    <figcaption>Caption.</figcaption>
  </figure>
  <div class="section section-top-tight center">
    <p><span class="dropcap">O</span>pening paragraph...</p>
  </div>
  <footer class="section">
    <hr />
    <p><strong>Author</strong> bio.</p>
  </footer>
</article>
```

### Feature Hero
```html
<header class="cover scheme-dark">
  <div class="center text-center">
    <h1 class="text-6xl">Feature Title</h1>
    <p class="lead">Subtitle.</p>
  </div>
</header>
```

### Statistics Grid
```html
<div class="grid grid-columns-4@md text-center">
  <div class="stack stack-compact">
    <p class="text-5xl font-bold">150</p>
    <p>Label</p>
  </div>
</div>
```

### Responsive Picture
```html
<picture>
  <source media="(min-width: 60em)" srcset="4x3.jpg" sizes="75vw" />
  <source media="(min-width: 40em)" srcset="3x2.jpg" sizes="50vw" />
  <source srcset="16x9.jpg" sizes="100vw" />
  <img src="fallback.jpg" alt="" loading="lazy" />
</picture>
```

## Best Practices

1. Start with semantic HTML - it looks good with zero classes
2. Add layout primitives first: `.stack`, `.grid`, `.cluster`, `.center`
3. Add utilities for art direction
4. Use `--line-*` tokens - never arbitrary pixel values
5. Use container queries (`@md`, `@lg`) over viewport media queries
6. Use HTML entities: `&mdash;`, `&middot;`, `&pound;`

## Code Style Guidelines

### Avoid Inline Styles
Always check if a utility class exists before adding inline styles. Live Wires has comprehensive utilities:

```html
<!-- BAD: inline styles -->
<div style="display: flex; align-items: center; justify-content: center;">

<!-- GOOD: utility classes -->
<div class="flex items-center justify-center">
```

### Use Scheme Classes Over bg-* + text-*
Scheme classes set both background AND text color together:

```html
<!-- BAD: separate bg and text classes -->
<div class="bg-black text-white">
<div class="bg-grey-200 text-black">

<!-- GOOD: scheme handles both -->
<div class="scheme-black">
<div class="scheme-grey-200">
<div class="scheme-subtle">
<div class="scheme-dark">
<div class="scheme-white">
<div class="scheme-accent">
```

### Use Box Classes for Padding
When you need consistent box padding, use `box` variants instead of `p-*` utilities:

```html
<!-- BAD: manual padding -->
<div class="p-4">

<!-- GOOD: semantic box padding -->
<div class="box">           <!-- Default padding -->
<div class="box box-tight"> <!-- Smaller padding -->
<div class="box box-loose"> <!-- Larger padding -->
```

### Keep Markup Minimal
Avoid unnecessary wrapper divs. Let layout primitives and utilities do the work:

```html
<!-- BAD: too many wrappers -->
<div class="box bg-subtle">
  <figure class="py-4">
    <div class="bg-white p-4" style="display: flex; align-items: center;">
      <div>
        <img src="..." />
      </div>
    </div>
  </figure>
</div>

<!-- GOOD: minimal, clean markup -->
<figure class="box scheme-white border">
  <img src="..." />
</figure>
```

### Simplify Before Adding
Before adding classes or elements, ask:
- Does a layout primitive already handle this?
- Can I combine classes instead of nesting divs?
- Is this wrapper actually necessary?
- Would a scheme class replace multiple color classes?

### Placeholder Images
Use placehold.co for all placeholder images:

```html
<!-- Basic placeholder -->
<img src="https://placehold.co/800x600" alt="Placeholder" />

<!-- With custom colors (background/text) -->
<img src="https://placehold.co/600x400/e5e5e5/888888?text=Logo" alt="Logo placeholder" />

<!-- Common patterns -->
<img src="https://placehold.co/800x800/e5e5e5/888888?text=Logomark" />  <!-- Square -->
<img src="https://placehold.co/600x200/e5e5e5/1a1a1a?text=Logo" />      <!-- Horizontal -->
<img src="https://placehold.co/120x120/1a1a1a/ffffff?text=Logo" />      <!-- Avatar dark -->
<img src="https://placehold.co/120x120/f5f5f5/1a1a1a?text=Logo" />      <!-- Avatar light -->
<img src="https://placehold.co/1920x1080" />                             <!-- Hero/full-width -->
```

Format: `https://placehold.co/{width}x{height}/{bg-color}/{text-color}?text={label}`

## ⚠️ Documentation Sync Requirement

**CRITICAL:** When modifying Live Wires CSS or adding new features, you MUST update documentation to stay in sync.

### After Any Code Change, Update:

| Change Type | Files to Update |
|-------------|-----------------|
| Layout primitives/variants | This file (SKILL.md), CLAUDE.md, manual/components/layout.html |
| Utility classes | This file (SKILL.md), CLAUDE.md |
| Tokens (`--line-*`, `--text-*`) | This file (SKILL.md), CLAUDE.md, README.md |
| Components | CLAUDE.md, relevant manual page |
| File structure | CLAUDE.md, README.md |

### Naming Conventions (MUST follow):

- Layout modifiers: **single-dash** (`stack-compact`, `box-tight`, `sidebar-reverse`)
- Spacing tokens: `--line-*` pattern
- Typography: Tailwind-style (`text-xs`, `text-sm`, `text-lg`, `text-2xl`, etc.)

### Quick Verification Checklist:

```
□ Class names in this file match actual CSS
□ All variants are documented
□ Token values are accurate
□ Examples use correct syntax
```

See CLAUDE.md for the complete documentation sync guide.
