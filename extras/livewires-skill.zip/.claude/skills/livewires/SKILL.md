---
name: livewires
description: Live Wires CSS framework for editorial websites. Use when building HTML pages, writing CSS, or advising on layout and styling. Provides layout primitives (stack, grid, cluster, sidebar, center, section, cover, reel), utility classes, and design tokens based on a baseline rhythm system.
---

# Live Wires CSS Framework

## Philosophy

**Good defaults + additive art direction.** Semantic HTML looks good with zero classes. Utility classes provide precise control for art direction.

**Nothing gets thrown away.** The prototype becomes the product. Every step builds on the last.

---

## ⚠️ CRITICAL: Prototyping Mindset

### DO NOT Create New CSS Classes

Live Wires has comprehensive layout primitives and utilities. **Never invent new class names.** If you think you need a new class, you're probably:

- Missing an existing utility (check this file)
- Over-engineering the solution
- Not trusting the defaults

```html
<!-- WRONG: Inventing classes -->
<div class="hero-container">
<div class="article-meta-wrapper">
<p class="subtitle-text">

<!-- RIGHT: Use existing primitives -->
<div class="cover">
<div class="cluster">
<p class="lead">
```

### Minimal Styling During Prototyping

Prototyping is about **structure and content**, not visual polish. Resist the urge to over-style.

**Headlines:** Let the semantic HTML work. `<h1>` through `<h6>` have good defaults. Only add size utilities (`text-4xl`, etc.) when there's a specific design reason.

```html
<!-- WRONG: Over-styled headline -->
<h1 class="text-6xl font-bold text-center mb-4 leading-tight">Article Title</h1>

<!-- RIGHT: Trust the defaults -->
<h1>Article Title</h1>
```

**Spacing:** Layout primitives handle spacing. Don't manually add `mt-*`, `mb-*`, `py-*` everywhere.

```html
<!-- WRONG: Manual spacing chaos -->
<section class="py-6">
  <h2 class="mb-4">Section Title</h2>
  <p class="mb-2">Paragraph one.</p>
  <p class="mb-2">Paragraph two.</p>
</section>

<!-- RIGHT: Let stack handle it -->
<section class="section">
  <h2>Section Title</h2>
  <p>Paragraph one.</p>
  <p>Paragraph two.</p>
</section>
```

**Supporting text:** Use `.lead` for intro paragraphs. Otherwise, let paragraph defaults work.

```html
<!-- WRONG: Over-styled supporting text -->
<p class="text-lg text-muted font-light leading-relaxed">Introduction to the article.</p>

<!-- RIGHT: Semantic and minimal -->
<p class="lead">Introduction to the article.</p>
```

### Page Types, Not Individual Pages

Think like a rapid prototyper. Build **reusable page templates**, not a page for every piece of content.

**BAD approach:**

```
/users/john-profile.html
/users/jane-profile.html
/users/bob-profile.html
/articles/article-one.html
/articles/article-two.html
/products/product-a.html
/products/product-b.html
```

**GOOD approach:**

```
/users/show.html        ← User profile template
/users/edit.html        ← User edit template
/articles/show.html     ← Article template
/articles/index.html    ← Article listing template
/products/show.html     ← Product template
```

When building a prototype:

1. **Identify the page types** (list, detail, form, dashboard, etc.)
2. **Build one template per type** with realistic placeholder content
3. **Reuse templates** - don't duplicate for each item
4. **Use the same edit page** for create and edit flows

### The Prototyping Test

Before adding any class, ask:

1. Does semantic HTML already handle this? → Use no class
2. Does a layout primitive handle this? → Use `.stack`, `.grid`, `.section`, etc.
3. Is this a scheme/theme concern? → Use `.scheme-*`
4. Is this specific art direction? → Only then use utilities

**Goal: The cleanest possible HTML that's ready for styling later.**

---

## The Design Process

Live Wires follows a sculptural approach—start with raw material, shape the form, refine the details, add expression.

### Step 1: Prototype in HTML
Build page templates using semantic HTML and layout primitives in the `public/` folder. Your prototype is instantly viewable in real browsers across devices. Share with clients, test UX flows, use the redact feature to focus on layout without words.

### Step 2: Set Your Tokens
Adjust design tokens (colors, typography, spacing) in `src/css/1_tokens/`. Watch the [Manual](/manual/) transform in real time. Every token you set designs the foundation of your project.

### Step 3: Refine and Express
Expand your CSS. Add utility classes for art direction. Refine components. Each iteration takes you from coarse to detailed—like carving marble.

### Step 4: Apply to Production
Connect your templates to your CMS or framework. Your prototype becomes the product. The same code, evolved—not translated.

**Alternative: CMS-first** — Install Live Wires directly on your CMS and start content modeling immediately with a prototype front-end.

## Documentation

### Framework Docs (`/docs/`)
How to use Live Wires - installation, architecture, reference:

- **[/docs/](http://localhost:3000/docs/)** — Documentation overview
- **[/docs/getting-started.html](http://localhost:3000/docs/getting-started.html)** — Installation and setup
- **[/docs/utility-classes.html](http://localhost:3000/docs/utility-classes.html)** — Spacing, typography, color utilities
- **[/docs/typography.html](http://localhost:3000/docs/typography.html)** — Typography system

### Manual (`/manual/`)
Brand identity and UI components. Edit tokens—this transforms in real time:

- **[/manual/](http://localhost:3000/manual/)** — Manual hub
- **[/manual/brand/](http://localhost:3000/manual/brand/)** — Logos, colors, fonts, voice & tone
- **[/manual/components/](http://localhost:3000/manual/components/)** — Layout primitives, forms, tables, schemes

Key component reference pages:
- **[Layout primitives](/manual/components/layout.html)** — Stack, grid, cluster, sidebar, center, section, cover, box, reel
- **[Typography](/manual/components/typography.html)** — Type scale, weights, alignment, special treatments
- **[Color schemes](/manual/components/schemes.html)** — Background/foreground pairings

## The Sacred Baseline System

All spacing derives from `--line`. Use `--line-*` tokens for spacing:

```
--line-0, --line-025, --line-05, --line-075, --line-1, --line-15, --line-2, --line-3, --line-4, --line-5, --line-6, --line-7, --line-8, --line-1px
```

## CSS Cascade Layers

```css
@layer tokens, reset, base, layouts, components, utilities;
```

Utilities always win over components, components over layouts, etc.

## Layout Primitives

### Stack (Vertical Spacing)
```html
<div class="stack">                  <!-- Default: var(--line) -->
<div class="stack stack-compact">    <!-- var(--line-025) -->
<div class="stack stack-half">       <!-- var(--line-05) -->
<div class="stack stack-comfortable"><!-- var(--line-2) -->
<div class="stack stack-spacious">   <!-- var(--line-4) -->
```

### Grid (Auto-Responsive)
```html
<div class="grid">                   <!-- Auto-fit -->
<div class="grid grid-narrow">       <!-- Narrower min column width -->
<div class="grid grid-columns-2">    <!-- Fixed columns -->
<div class="grid grid-columns-2@md"> <!-- 2 cols at 40rem+ container -->
<div class="grid grid-columns-3@lg"> <!-- 3 cols at 60rem+ container -->
<div class="grid-column-span-2">     <!-- Span columns -->
<div class="grid-column-span-2@md">  <!-- Responsive span -->
```

### Cluster (Horizontal Grouping)
```html
<nav class="cluster">
<div class="cluster cluster-compact">  <!-- var(--line-05) gap -->
<div class="cluster cluster-center">   <!-- justify-content: center -->
<div class="cluster cluster-end">      <!-- justify-content: flex-end -->
<div class="cluster cluster-between">  <!-- justify-content: space-between -->
<div class="cluster cluster-nowrap">   <!-- flex-wrap: nowrap (for headers) -->
```

### Sidebar
```html
<div class="sidebar">
<div class="sidebar sidebar-snug">     <!-- var(--line-1) gap -->
<div class="sidebar sidebar-loose">    <!-- var(--line-2) gap -->
<div class="sidebar sidebar-reverse">  <!-- Sidebar on right -->
```

### Center (Max-Width Container)
```html
<div class="center">
<div class="center center-narrow">
<div class="center center-wide">
```

### Section (Vertical Padding)
```html
<section class="section">
<section class="section section-spaced">       <!-- Top + bottom padding -->
<section class="section section-snug">         <!-- Smaller top + bottom -->
<section class="section section-tight">        <!-- No vertical padding -->
<section class="section section-top-tight">    <!-- No top padding -->
<section class="section section-bottom-tight"> <!-- No bottom padding -->
<section class="section section-wide">         <!-- Narrower horizontal padding -->
<section class="section section-full-bleed">   <!-- No padding at all -->
```

### Cover (Full-Height Centering)
```html
<header class="cover">  <!-- min-height: 100vh, flexbox centering -->
```

### Box (Padding Wrapper)
```html
<div class="box">         <!-- var(--line-1) padding -->
<div class="box box-tight"> <!-- var(--line-05) padding -->
<div class="box box-loose"> <!-- var(--line-2) padding -->
```

### Reel (Horizontal Scrolling)
```html
<div class="reel">                   <!-- Default horizontal scroll -->
<div class="reel reel-narrow">       <!-- 8 lines item width -->
<div class="reel reel-medium">       <!-- 12 lines item width -->
<div class="reel reel-wide">         <!-- 16 lines item width -->
<div class="reel reel-compact">      <!-- var(--line-05) gap -->
<div class="reel reel-spacious">     <!-- var(--line-2) gap -->
<div class="reel reel-no-scrollbar"> <!-- Hidden scrollbar -->
<div class="reel reel-padded">       <!-- Bottom padding for overflow -->
```

### Imposter (Overlay Positioning)

```html
<div class="imposter">              <!-- Absolutely centered in parent -->
<div class="imposter-fixed">        <!-- Fixed to viewport -->
<dialog class="imposter-dialog">    <!-- Optimized for <dialog> -->
<dialog class="imposter-dialog imposter-contain"> <!-- Prevents overflow -->
```

## Components

### Dialogs and Modals
```html
<!-- Basic dialog -->
<dialog class="dialog imposter-dialog imposter-contain">
  <div class="dialog-content box stack">
    <header class="dialog-header cluster cluster-between cluster-nowrap">
      <h2 class="dialog-title">Title</h2>
      <button class="dialog-close" aria-label="Close">&times;</button>
    </header>
    <p>Content here.</p>
    <footer class="dialog-actions cluster cluster-end">
      <button class="button">Cancel</button>
      <button class="button button--accent">Confirm</button>
    </footer>
  </div>
</dialog>

<!-- Size variants -->
<dialog class="dialog dialog--narrow">  <!-- 20rem max -->
<dialog class="dialog">                 <!-- 24rem max (default) -->
<dialog class="dialog dialog--wide">    <!-- 32rem max -->
```

### Footnotes (Web Component)

```html
<!-- Superscript number -->
<p>A key finding<foot-note def="Source: Study 2024"><sup>1</sup></foot-note> shows...</p>

<!-- Symbol -->
<p>Prices start at $99<foot-note def="Valid for annual billing">*</foot-note></p>

<!-- Inline term with title -->
<p>Uses a <foot-note def="A reusable CSS pattern" title="Layout Primitive">layout primitive</foot-note></p>

<!-- Attributes: def (required), title (optional, defaults to "Note") -->
<!-- API: note.open(), note.close() -->
```

### Popup Dialog (Web Component)
```html
<!-- Confirmation dialog -->
<popup-dialog
  title="Delete item?"
  body="This action cannot be undone."
  confirm-label="Delete"
  confirm-variant="red">
  <button class="button button--red">Delete</button>
</popup-dialog>

<!-- With navigation -->
<popup-dialog title="Leave?" body="Unsaved changes." confirm-href="/home/">
  <a href="/home/">Leave</a>
</popup-dialog>

<!-- Info popup (no actions) -->
<popup-dialog title="About" no-cancel>
  <button class="button">Learn more</button>
  <div slot="body"><p>Custom content.</p></div>
  <div slot="actions"><button data-action="close">Got it</button></div>
</popup-dialog>

<!-- Attributes: title, body, confirm-label, cancel-label, confirm-href, confirm-variant ("accent"|"red"), no-cancel -->
<!-- Events: confirm -->
<!-- API: popup.open(), popup.close(), popup.confirm() -->
```

### Status Indicators
```html
<!-- Semantic variants -->
<span class="status-indicator">Default</span>
<span class="status-indicator status-indicator--success">Healthy</span>
<span class="status-indicator status-indicator--warning">Warning</span>
<span class="status-indicator status-indicator--error">Error</span>

<!-- Color variants -->
<span class="status-indicator status-indicator--green">Green</span>
<span class="status-indicator status-indicator--yellow">Yellow</span>
<span class="status-indicator status-indicator--orange">Orange</span>
<span class="status-indicator status-indicator--red">Red</span>
<span class="status-indicator status-indicator--blue">Blue</span>

<!-- Size variants -->
<span class="status-indicator status-indicator--small">Small</span>
<span class="status-indicator status-indicator--large">Large</span>

<!-- Without text (add aria-label) -->
<span class="status-indicator status-indicator--success" aria-label="Online"></span>
```

### Badges

```html
<!-- Color variants -->
<span class="badge badge--blue">Blue</span>
<span class="badge badge--green">Green</span>
<span class="badge badge--orange">Orange</span>
<span class="badge badge--yellow">Yellow</span>
<span class="badge badge--red">Red</span>
<span class="badge badge--grey">Grey</span>

<!-- Status variants -->
<span class="badge badge--draft">Draft</span>
<span class="badge badge--pending">Pending</span>
<span class="badge badge--active">Active</span>
<span class="badge badge--archived">Archived</span>

<!-- Feedback variants -->
<span class="badge badge--success">Success</span>
<span class="badge badge--warning">Warning</span>
<span class="badge badge--error">Error</span>
<span class="badge badge--info">Info</span>

<!-- Size variants -->
<span class="badge badge--blue badge--small">Small</span>
<span class="badge badge--blue badge--large">Large</span>
```

### Progress Bars

```html
<!-- Basic progress bar -->
<div class="progress-bar">
  <div class="fill" style="width: 65%"></div>
</div>

<!-- Thick variant -->
<div class="progress-bar progress-bar--thick">
  <div class="fill" style="width: 45%"></div>
</div>

<!-- Stacked bar (distribution breakdown) -->
<div class="stacked-bar">
  <div class="segment segment--primary" style="width: 40%"></div>
  <div class="segment segment--secondary" style="width: 35%"></div>
  <div class="segment segment--muted" style="width: 25%"></div>
</div>
```

## Typography Utilities

```html
<!-- Sizes -->
<p class="text-xs">  <p class="text-sm">  <p class="text-base">
<p class="text-lg">  <p class="text-xl">  <p class="text-2xl">
<p class="text-3xl"> <p class="text-4xl"> <p class="text-5xl"> <p class="text-6xl">
<p class="text-7xl"> <p class="text-8xl"> <p class="text-9xl">

<!-- Responsive sizes (container queries) -->
<h1 class="text-4xl text-6xl@md text-8xl@lg">  <!-- Scales up at breakpoints -->

<!-- Weights -->
<p class="font-light">  <p class="font-normal">  <p class="font-medium">
<p class="font-semibold">  <p class="font-bold">  <p class="font-black">

<!-- Alignment -->
<p class="text-left">  <p class="text-center">  <p class="text-right">

<!-- Special -->
<p class="lead">       <!-- Larger intro paragraph -->
<p class="measure">    <!-- Optimal reading width (65ch) -->
<span class="dropcap"> <!-- Large initial letter -->
```

## Spacing Utilities

```html
<!-- Margin: mt, mb, my, ml, mr, mx -->
<div class="mt-2">  <!-- margin-block-start: var(--line-2) -->
<div class="mb-3">  <!-- margin-block-end: var(--line-3) -->
<div class="my-4">  <!-- margin-block: var(--line-4) -->

<!-- Padding: pt, pb, py, pl, pr, px, p -->
<div class="py-3">  <!-- padding-block: var(--line-3) -->
<div class="px-2">  <!-- padding-inline: var(--line-2) -->
<div class="p-4">   <!-- padding: var(--line-4) -->
```

Values: 0, 025, 05, 075, 1, 15, 2, 3, 4, 5, 6

## Color Schemes

```html
<section class="scheme-subtle">    <!-- Light grey -->
<section class="scheme-dark">      <!-- Dark bg, light text -->
<section class="scheme-grey-100">  <!-- Grey 100 -->
<section class="scheme-grey-200">  <!-- Grey 200 -->

<!-- Background/text colors -->
<div class="bg-white">  <div class="bg-black">  <div class="bg-grey-100">
<p class="text-white">  <p class="text-muted">  <p class="text-grey-500">
```

## Container Query Breakpoints

- `@md` = 40rem container width
- `@lg` = 60rem container width

```html
<!-- Grid -->
<div class="grid-columns-2@md">     <!-- 2 cols at 40rem+ -->
<div class="grid-column-span-2@lg"> <!-- Span 2 at 60rem+ -->

<!-- Typography -->
<h1 class="text-4xl text-6xl@md text-8xl@lg"> <!-- Scales up at breakpoints -->

<!-- Order -->
<div class="order-first@md">        <!-- Order first at 40rem+ -->
```

## Common Patterns

### Article Structure
```html
<article class="prose">
  <header class="section scheme-subtle">
    <h1 class="text-6xl">Title</h1>
    <p class="lead">Subtitle.</p>
    <p>By Author &middot; <time datetime="2024-01-15">January 15, 2024</time></p>
  </header>
  <figure class="section section-tight">
    <img src="hero.jpg" alt="" />
    <figcaption>Caption.</figcaption>
  </figure>
  <div class="section section-top-tight center">
    <p><span class="dropcap">O</span>pening paragraph...</p>
  </div>
  <footer class="section">
    <hr />
    <p><strong>Author</strong> bio.</p>
  </footer>
</article>
```

### Feature Hero
```html
<header class="cover scheme-dark">
  <div class="center text-center">
    <h1 class="text-6xl">Feature Title</h1>
    <p class="lead">Subtitle.</p>
  </div>
</header>
```

### Statistics Grid
```html
<div class="grid grid-columns-4@md text-center">
  <div class="stack stack-compact">
    <p class="text-5xl font-bold">150</p>
    <p>Label</p>
  </div>
</div>
```

### Responsive Picture
```html
<picture>
  <source media="(min-width: 60em)" srcset="4x3.jpg" sizes="75vw" />
  <source media="(min-width: 40em)" srcset="3x2.jpg" sizes="50vw" />
  <source srcset="16x9.jpg" sizes="100vw" />
  <img src="fallback.jpg" alt="" loading="lazy" />
</picture>
```

## Best Practices

1. Start with semantic HTML - it looks good with zero classes
2. Add layout primitives first: `.stack`, `.grid`, `.cluster`, `.center`
3. Add utilities for art direction
4. Use `--line-*` tokens - never arbitrary pixel values
5. Use container queries (`@md`, `@lg`) over viewport media queries
6. Use HTML entities: `&mdash;`, `&middot;`, `&pound;`

## Code Style Guidelines

### Avoid Inline Styles
Always check if a utility class exists before adding inline styles. Live Wires has comprehensive utilities:

```html
<!-- BAD: inline styles -->
<div style="display: flex; align-items: center; justify-content: center;">

<!-- GOOD: utility classes -->
<div class="flex items-center justify-center">
```

### Use Scheme Classes Over bg-* + text-*
Scheme classes set both background AND text color together:

```html
<!-- BAD: separate bg and text classes -->
<div class="bg-black text-white">
<div class="bg-grey-200 text-black">

<!-- GOOD: scheme handles both -->
<div class="scheme-black">
<div class="scheme-grey-200">
<div class="scheme-subtle">
<div class="scheme-dark">
<div class="scheme-white">
<div class="scheme-accent">
```

### Use Box Classes for Padding
When you need consistent box padding, use `box` variants instead of `p-*` utilities:

```html
<!-- BAD: manual padding -->
<div class="p-4">

<!-- GOOD: semantic box padding -->
<div class="box">           <!-- Default padding -->
<div class="box box-tight"> <!-- Smaller padding -->
<div class="box box-loose"> <!-- Larger padding -->
```

### Keep Markup Minimal
Avoid unnecessary wrapper divs. Let layout primitives and utilities do the work:

```html
<!-- BAD: too many wrappers -->
<div class="box bg-subtle">
  <figure class="py-4">
    <div class="bg-white p-4" style="display: flex; align-items: center;">
      <div>
        <img src="..." />
      </div>
    </div>
  </figure>
</div>

<!-- GOOD: minimal, clean markup -->
<figure class="box scheme-white border">
  <img src="..." />
</figure>
```

### Simplify Before Adding
Before adding classes or elements, ask:
- Does a layout primitive already handle this?
- Can I combine classes instead of nesting divs?
- Is this wrapper actually necessary?
- Would a scheme class replace multiple color classes?

### Placeholder Images
Use placehold.co for all placeholder images:

```html
<!-- Basic placeholder -->
<img src="https://placehold.co/800x600" alt="Placeholder" />

<!-- With custom colors (background/text) -->
<img src="https://placehold.co/600x400/e5e5e5/888888?text=Logo" alt="Logo placeholder" />

<!-- Common patterns -->
<img src="https://placehold.co/800x800/e5e5e5/888888?text=Logomark" />  <!-- Square -->
<img src="https://placehold.co/600x200/e5e5e5/1a1a1a?text=Logo" />      <!-- Horizontal -->
<img src="https://placehold.co/120x120/1a1a1a/ffffff?text=Logo" />      <!-- Avatar dark -->
<img src="https://placehold.co/120x120/f5f5f5/1a1a1a?text=Logo" />      <!-- Avatar light -->
<img src="https://placehold.co/1920x1080" />                             <!-- Hero/full-width -->
```

Format: `https://placehold.co/{width}x{height}/{bg-color}/{text-color}?text={label}`

## ⚠️ Documentation Sync Requirement

**CRITICAL:** When modifying Live Wires CSS or adding new features, you MUST update documentation to stay in sync.

### After Any Code Change, Update:

| Change Type | Files to Update |
|-------------|-----------------|
| Layout primitives/variants | This file (SKILL.md), CLAUDE.md, manual/components/layout.html |
| Utility classes | This file (SKILL.md), CLAUDE.md |
| Tokens (`--line-*`, `--text-*`) | This file (SKILL.md), CLAUDE.md, README.md |
| Components | CLAUDE.md, relevant manual page |
| File structure | CLAUDE.md, README.md |

### Naming Conventions (MUST follow):

- Layout modifiers: **single-dash** (`stack-compact`, `box-tight`, `sidebar-reverse`)
- Spacing tokens: `--line-*` pattern
- Typography: Tailwind-style (`text-xs`, `text-sm`, `text-lg`, `text-2xl`, etc.)

### Quick Verification Checklist:

```
□ Class names in this file match actual CSS
□ All variants are documented
□ Token values are accurate
□ Examples use correct syntax
```

See CLAUDE.md for the complete documentation sync guide.

---

## QA Testing a Live Wires Prototype

Use this system to audit prototypes for consistency, accessibility, and Live Wires compliance.

### ⚠️ CRITICAL: Test ALL Pages

**Do not skip subpages.** A common failure mode is testing top-level pages and missing nested pages entirely.

Before starting QA:

1. **Discover all HTML files** in the prototype (exclude `/docs/`, `/example/`, `/manual/`)
2. **Create a complete page list** including ALL subdirectories
3. **Test every single page** - no exceptions

```bash
# Find all prototype pages to test
find public -name "*.html" | grep -v -E "(docs|example|manual)" | sort
```

Example of what to test:

```
✓ /index.html
✓ /about.html
✓ /users/index.html      ← Don't skip!
✓ /users/show.html       ← Don't skip!
✓ /users/edit.html       ← Don't skip!
✓ /articles/index.html   ← Don't skip!
✓ /articles/show.html    ← Don't skip!
✓ /dashboard/index.html  ← Don't skip!
✓ /dashboard/settings.html ← Don't skip!
```

**Excluded directories** (framework docs, not prototype):

- `/docs/` - Live Wires documentation
- `/example/` - Example implementation
- `/manual/` - Brand manual/component library

### Core Testing Objectives

#### ⚠️ THOROUGH Link Testing (Every Link, Every Page)

**Test EVERY link on EVERY page**, not just navigation. This includes:

- Navigation links (header, footer, sidebar)
- In-content links (within paragraphs, lists, cards)
- Button links (`<a>` styled as buttons)
- Image links (clickable images/figures)
- Icon links (social icons, action icons)
- Breadcrumb links
- Pagination links
- "Read more" / "View all" links
- Footer links (legal, sitemap, etc.)

**For each link, verify:**

- Internal links resolve to existing prototype pages (no 404s)
- Anchor links (`#section`) scroll to the correct section
- External links open in new tab with `target="_blank" rel="noopener noreferrer"`
- No empty `href=""` or `href="#"` placeholder links
- No dead-end pages (pages with no way to navigate away)

#### JavaScript Console Audit

**Check browser console on EVERY page for:**

- JavaScript errors (red) — must fix
- JavaScript warnings (yellow) — should review
- Failed network requests (404s for scripts, styles, images)
- Web component initialization errors
- Uncaught exceptions or promise rejections

**Common JS issues to catch:**

- Web components not registering (check custom element definitions)
- Missing dependencies or imports
- Event listeners on non-existent elements
- Incorrect paths to JS modules

#### Form Testing

**For every form in the prototype:**

- `action` attribute points to an existing page (e.g., `action="/users/show.html"`)
- `method` attribute is set appropriately (`GET` or `POST`)
- Required fields have `required` attribute
- Form inputs have associated `<label>` elements (for/id match)
- Submit buttons are inside the form or use `form="formId"`
- Form validation states render correctly (`:invalid`, `:valid`)

**Test form flows:**

- Submit the form and verify it lands on the correct page
- Check that "Cancel" buttons navigate back appropriately
- Verify edit forms and create forms share templates where logical

#### Image and Media Audit

- No broken images (check for 404s in Network tab)
- All `<img>` elements have `alt` attributes (can be empty for decorative)
- Images load at appropriate sizes (not oversized)
- Placeholder images use consistent service (placehold.co)
- Video embeds render correctly (if any)

#### Interactive Element Verification

- Test all buttons for hover, focus, and active states
- Verify every clickable element has a visible focus indicator
- Test keyboard navigation (Tab through entire page)
- Check web components render and function correctly
- Dialog/modal open and close correctly
- Dropdowns and toggles work as expected

#### Layout and Responsive Behavior

- Compare header/footer appearance across all pages
- Verify spacing and alignment is consistent page-to-page
- Check responsive behavior at 320px, 768px, 1024px, and 1440px
- Flag layout breaks, overflow, or unexpected scrollbars
- Test horizontal scroll (should only exist intentionally, e.g., `.reel`)

#### Typography Audit

- Check heading hierarchy: each page has exactly ONE `<h1>`, headings follow h1→h2→h3 order
- Verify font weights and families are consistent per heading level
- Flag excessive utility class usage for typography that should be handled by defaults
- No orphaned text (text outside proper containers)

#### Live Wires Compliance Audit

- No inline styles: Flag any `style="..."` attributes
- No invented classes: Only use existing Live Wires classes
- Correct naming: Layouts use single-dash, components use double-dash
- State handling: Uses `data-*` attributes, not state classes
- Semantic HTML: Proper landmarks (`<header>`, `<nav>`, `<main>`, `<footer>`, `<aside>`)

### Quick Checklist by Component

#### Navigation checklist

| Check | Pass |
| ----- | ---- |
| All nav links resolve to valid pages | ☐ |
| Active state uses `data-state="active"` or `[data-active]` | ☐ |
| Focus states visible on all links | ☐ |
| Keyboard accessible | ☐ |

#### Headlines checklist

| Check | Pass |
| ----- | ---- |
| Each page has exactly ONE `<h1>` | ☐ |
| Headings follow logical order (no skipping levels) | ☐ |
| h1-h6 styled at element level (minimal utility classes) | ☐ |
| Consistent sizing/weight per level across pages | ☐ |

#### Buttons checklist

| Check | Pass |
| ----- | ---- |
| Visible hover state | ☐ |
| Visible focus state (critical for a11y) | ☐ |
| Disabled buttons use `[data-state="disabled"]` | ☐ |
| Variants use `--` syntax (`.button--red`) | ☐ |

#### Layout primitives checklist

| Check | Pass |
| ----- | ---- |
| Layout variants use single-dash (`.stack-compact`) | ☐ |
| No inline styles for layout adjustments | ☐ |
| Primitives handle structure, not visual styling | ☐ |

#### Links checklist (per page)

| Check | Pass |
| ----- | ---- |
| All internal links resolve to existing pages | ☐ |
| No empty `href=""` or `href="#"` placeholders | ☐ |
| Anchor links scroll to correct sections | ☐ |
| External links have `target="_blank" rel="noopener noreferrer"` | ☐ |
| No dead-end pages (every page has navigation out) | ☐ |

#### Forms checklist

| Check | Pass |
| ----- | ---- |
| Form `action` points to existing page | ☐ |
| Form has appropriate `method` attribute | ☐ |
| All inputs have associated `<label>` elements | ☐ |
| Required fields have `required` attribute | ☐ |
| Submit button is inside form or uses `form` attribute | ☐ |
| Form submission lands on correct page | ☐ |

#### Console checklist (per page)

| Check | Pass |
| ----- | ---- |
| No JavaScript errors (red) | ☐ |
| No failed network requests (404s) | ☐ |
| Web components initialize correctly | ☐ |
| No uncaught exceptions | ☐ |

#### Images checklist

| Check | Pass |
| ----- | ---- |
| No broken images (404s) | ☐ |
| All images have `alt` attributes | ☐ |
| Placeholder images use placehold.co | ☐ |

### Live Wires Compliance Criteria

#### Naming conventions

| Layer | Pattern | Examples |
| ----- | ------- | -------- |
| Utility | `.{abbrev}-{value}` | `.mt-4`, `.text-center`, `.scheme-warm` |
| Layout | `.{layout}` or `.{layout}-{variant}` | `.stack`, `.stack-compact` |
| Component | `.{component}--{variant}` | `.button--red`, `.table--bordered` |
| State | `[data-state="{state}"]` | `[data-state="active"]`, `[data-open]` |

#### Key rules

- NO BEM `__` syntax for child elements—use CSS nesting
- NO class prefixes like `.c-`, `.m-`, `.u-`
- NO invented class names—use existing primitives
- NO inline styles—use utility classes
- State uses `data-*` attributes, not classes

**Class Order in HTML** (general to specific):

1. Layout/composition (`.stack`, `.grid`)
2. Block/component (`.callout`, `.button`)
3. Variant modifiers (`.button--red`)
4. Utility classes (`.mt-4`, `.scheme-warm`)

### Common Issue Shortcodes

Use these for efficient documentation:

```
LINK-BROKEN   — Link leads to 404 or non-existent page
LINK-EMPTY    — Empty href="" or href="#" placeholder
LINK-ANCHOR   — Anchor link doesn't scroll to target
LINK-EXTERNAL — External link missing target/rel attributes
NAV-DEADEND   — Page has no outbound navigation

FORM-ACTION   — Form action points to non-existent page
FORM-LABEL    — Input missing associated label
FORM-METHOD   — Form missing method attribute
FORM-SUBMIT   — Submit button outside form without form attribute

JS-ERROR      — JavaScript error in console
JS-NETWORK    — Failed network request (404 for asset)
JS-COMPONENT  — Web component failed to initialize

IMG-BROKEN    — Image returns 404
IMG-ALT       — Image missing alt attribute

TYP-HIERARCHY — Heading level skipped (h1→h3)
TYP-DUPLICATE — Multiple h1 elements on page
TYP-UTILITY   — Excessive utility classes for typography

A11Y-FOCUS    — Missing visible focus state
A11Y-KEYBOARD — Element not keyboard accessible
A11Y-LABEL    — Interactive element missing accessible name

LW-INLINE     — Inline style attribute
LW-INVENTED   — Invented class name (not in Live Wires)
LW-BEM        — BEM syntax used (should use CSS nesting)
LW-STATE      — State class used (should use data-*)
LW-VARIANT    — Wrong variant syntax (single vs double dash)

LAYOUT-BREAK  — Layout breaks at specific viewport
LAYOUT-SCROLL — Unexpected horizontal scroll
```

### QA Testing Procedure

**For each page in the prototype:**

1. **Open browser DevTools** before navigating to the page
2. **Check Console tab** — note any errors or warnings
3. **Check Network tab** — note any failed requests (404s)
4. **Click every link** on the page — verify destination exists
5. **Test every form** — submit and verify action page exists
6. **Tab through the page** — verify focus states and keyboard access
7. **Resize viewport** — check 320px, 768px, 1024px, 1440px
8. **Inspect the HTML** — check for compliance issues

**Do not move to the next page until current page passes all checks.**

### The Three Questions for Every Element

1. **Is this semantic HTML styled by default?** If adding typography utilities to `<p>`, `<h1-h6>`, `<ul>`, `<blockquote>`—that's likely a violation.

2. **Are inline styles used?** Any `style="..."` should be replaced with existing utility classes.

3. **Is this an invented class?** Every class should exist in Live Wires. If you need a new class, reconsider the approach.

### The Sculpture Test

Disable CSS temporarily. Does the HTML structure still communicate hierarchy and meaning? If the page becomes incomprehensible, the HTML isn't semantic enough.
